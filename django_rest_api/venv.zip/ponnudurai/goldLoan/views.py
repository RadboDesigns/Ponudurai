from django.shortcuts import redirect, render
from goldLoan.models import *  # Import from api app if models are there

def dashboard(request):
    latest_prices = LivePrice.objects.first()  
    return render(request, 'index.html', {'latest_prices': latest_prices})

def scheme_list(request):
    schemes = JoinScheme.objects.all()
    return render(request, 'schemes.html', {'schemes': schemes})

def show_feeds(request):
    feeds = Feeds.objects.all()
    return render(request, 'showFeeds.html', {'feeds': feeds})

def add_feeds(request):
    if request.method == 'POST':
        feeds_title = request.POST.get('feedsTitle')
        context_text = request.POST.get('context')
        image_file = request.FILES.get('image') if 'image' in request.FILES else None

        new_feeds = Feeds(
            feedsTitle = feeds_title,
            context = context_text,
            image = image_file
        )
        new_feeds.save()
        return redirect('show_feeds')
    return render(request, 'feeds.html')

def show_users(request):
    users = User.objects.all()
    print(users)
    return render(request, 'users.html', {'users': users})

def add_users(request):
    pass

def show_transation(request):
    transation = Payment.objects.all()
    return render(request, 'transactions.html', {'transaction': transation})


from django.apps import AppConfig


class GoldloanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'goldLoan'

from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('schemes/', views.scheme_list, name='scheme_list'),

    path('feeds/', views.show_feeds, name='show_feeds'),
    path('feeds/add/', views.add_feeds, name='add_feeds'),

    path('users/', views.show_users, name='show_users'),
    path("users/add", views.add_users, name='add_users'),
    
    path('transation/', views.show_transation, name='show_transation'),
]